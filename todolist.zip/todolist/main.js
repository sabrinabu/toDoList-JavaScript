function createCloseBtn(){
  let myNodeList=document.getElementsByTagName("li");

  for(let i=0; i<myNodeList.length; i++){
     let span=document.createElement("span");
     let text=document.createTextNode("\u00D7");
     span.className="close";
     span.appendChild(text);
     myNodeList[i].appendChild(span);
  }
}
createCloseBtn();

//Add new list to the box 

function newAdd(){
  let li=document.createElement("li");
  let inputValue=document.getElementById("myInput").value;
  let text=document.createTextNode(inputValue);
  li.appendChild(text);
  if(inputValue===""){
    alert("please enter text herr");
  }else{
     document.getElementById("myUL").appendChild(li);
  }
  createCloseBtn();
  document.getElementById("myInput").value="";
  hideBtn();
}

// Click on a close button to hide the current list item
function hideBtn(){
  let myNodeList=document.getElementsByTagName("li");
    for(let i=0; i<myNodeList.length; i++){
      myNodeList[i].onclick=function(){
        myNodeList[i].style.display="none";
    }
  }
 
}
hideBtn();